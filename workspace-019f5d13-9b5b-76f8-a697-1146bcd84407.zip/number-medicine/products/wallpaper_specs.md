# WALLPAPER & PRODUCT PRODUCTION SPECS
## Number Medicine · Feel · Form · Move · Sky

---

## System reminder

| Forms | Sky |
|-------|-----|
| **1–8** | Mapped eight: Sun · Mercury · Venus · Mars · Earth · Jupiter · Saturn · Neptune |
| **9** | **Beyond the eight** — Universe · the Unknown (**never** a planet) |

Every wallpaper can carry:

1. **Image** (nature medicine)  
2. Optional **glyph** (kinetic form)  
3. Optional **sky pill** (mapped light or Beyond)  
4. Optional whisper **Move** line (lock screens only if it stays quiet)

---

## PHONE WALLPAPERS

**Size:** 1290 × 2796 px (iPhone base) + Android 1440 × 3200  
**Safe zones:** Keep primary subject in center ~70% vertical band  

| Variant | Treatment |
|---------|-----------|
| Light | Ivory / gold-hour masters |
| Dark | Deep ocean / soft black regrade for OLED |

### Dual / triple layer sets

| Form | Sky pill text | Notes |
|------|---------------|--------|
| 1 | ☀ Sun | Source / love |
| 2 | ☿ Mercury | Sharing |
| 3 | ♀ Venus | Desire |
| 4 | ♂ Mars | Purpose / focus |
| 5 | 🌍 Earth | Self |
| 6 | ♃ Jupiter | Joy — keep free |
| 7 | ♄ Saturn | Balance |
| 8 | ♆ Neptune | Home |
| 9 | ✦ Beyond | Universe · the Unknown |

**Suggested daily rotation**

- Morning lock: **6** or **1**  
- Focus hours: **4**  
- Evening: **8** or **7**  
- Night: **9** (beyond)

---

## DESKTOP WALLPAPERS

| Format | Size |
|--------|------|
| Standard 16:9 | 3840 × 2160 |
| Ultrawide 21:9 | 5120 × 2160 |
| Mac 16:10 | 3840 × 2400 |

Best wide masters: **9**, **7**, **6**, **2**.  
Keep sky pill small — bottom-left or bottom-right, never covering the emotional heart of the image.

---

## T-SHIRT / HOODIE

| Placement | Spec |
|-----------|------|
| Chest | 10–12 cm symbol or digit + word |
| Back | Full artwork 28–35 cm |
| Optional | Tiny sky pill under hem or sleeve |

**Signature pieces**

- Hoodie **8 HOME** (cabin)  
- Tee **1 LOVE** (single tree)  
- Tee **5 SELF** (rings)  
- Tee **9** — glyph + “Beyond” only (no planet language)

---

## POSTER / CANVAS

| Size | Use |
|------|-----|
| 30 × 40 cm | Desk / gift |
| 50 × 70 cm | Primary wall |
| 70 × 100 cm | Statement |
| Square 50 × 50 | **5**, **7** |

Museum giclée, cotton rag, wide ivory mat.  
Optional metal plate on side: digit only — or digit + sky symbol.

---

## JOURNAL / NOTEBOOK

- Cover: linen / soft-touch, deboss glyph or tree rings  
- Ribbon: sunset gold or forest  
- Opening page: *Feel · Form · Move · Sky*  
- Optional “ring journal” for form **5**

---

## MEDITATION / CARDS

See live mockup: `products/meditation_cards.html`

- Front: image + glyph + sky pill + word  
- Reverse: Feel · Form · Move · Sky  
- Edge cards: sky law, pairs, wild cue  

---

## SOCIAL

See live mockup: `products/social_carousel.html`

Full path: Title → Kinetic map → **Eight · then beyond** → nine forms → close.

Caption template:

> Feel: …  
> Move: …  
> Sky: … (mapped eight / beyond)  
> Trace the glyph once.

---

## FILE NAMING

```
NM_01_LOVE_master.jpg
NM_01_LOVE_phone_light.png
NM_01_LOVE_phone_dark.png
NM_01_LOVE_desktop_16x9.png
NM_01_LOVE_sky_sun.png
NM_09_UNIVERSE_beyond.png
```

Color: sRGB screen · Adobe RGB / ProPhoto print masters · CMYK proof separately.

---

*Number Medicine · Production specs · Eight then beyond*
