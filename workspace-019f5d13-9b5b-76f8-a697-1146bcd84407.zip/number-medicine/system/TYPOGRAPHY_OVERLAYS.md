# TYPOGRAPHY OVERLAY SYSTEM
## Number Medicine — Type Specs for Production

Use these exact specs when compositing type onto the nine artworks in Figma, Photoshop, or print prepress.

---

### GLOBAL TYPE RULES

| Element | Font | Weight | Size (relative) | Tracking | Color |
|---------|------|--------|-----------------|----------|-------|
| Number | Neue Haas Grotesk Display / Inter Tight | Light (300) | 18–28% of shortest side | +80 to +120 | Soft Black 35–55% or Moon White 40% |
| Word | Cormorant Garamond / EB Garamond | Medium / Regular | 2.5–4% of shortest side | +180 to +280 (small caps preferred) | Soft Black 80% or Copper |
| Philosophy (editorial only) | Same serif | Regular italic | 1.5–2% | +20 | Soft Black 60% |

**Never** place type over the emotional heart of the image.  
**Always** leave breathing room equal to at least the height of the word.

---

### PER-NUMBER PLACEMENT

**1 LOVE** — Number lower-left. Word lower-right. Both baseline-aligned.  
**2 SHARING** — Number top-center light watermark. Word bottom-center.  
**3 DESIRE** — Number lower-left moon white. Word upper-right tiny.  
**4 PURPOSE** — Number mid-right. Word along path dust (bottom).  
**5 SELF** — Number as thin engraved arc in outer ring OR lower-left. Word bottom-center.  
**6 JOY** — Number upper-left ivory/gold. Word lower-right.  
**7 BALANCE** — Number in sky half. Word in water half (mirrored positions).  
**8 HOME** — Number left of cabin in sky. Word under glowing window.  
**9 THE UNIVERSE** — Number integrated in whale curve or constellation. Word along water edge.

---

### PRINT SAFE ZONES

- Posters: 15 mm from trim  
- Cards: 8 mm from edge  
- Apparel: keep type out of armpit/side seam stress areas  
- Phone wallpapers: respect Dynamic Island / notch / home indicator  

---

### ACCESSIBILITY NOTE

The system is visual-first. Type is a whisper for those who want the word; the image alone should carry the feeling.


---

## Sky pill (UI + print)

| Element | Spec |
|---------|------|
| Placement | Bottom-left on image (gallery & cards) |
| Type | Uppercase micro sans, tracking ~0.1em |
| Chip | Deep ocean ~78% opacity · gold border hairline · ivory text |
| Forms 1–8 | `☀ Sun` … `♆ Neptune` |
| Form 9 | `✦ Beyond` (expand in detail: Universe · the Unknown) |
| Never | “Planet” language on form 9 |

## Interactive tabs (main site)

| Element | Spec |
|---------|------|
| Style | Pill buttons, not ultra-tracked inline links |
| Active | Forest fill · moon text |
| Behavior | Sticky · scroll-spy · smooth scroll · horizontal overflow on mobile |
| Labels | Philosophy · The Map · The Nine · Kinetic Path · Twin Facts · Celestial · Practice · Applications · System · Products · Cards · Carousel |
