# NUMBER MEDICINE
## Design Bible · Creative Constitution

Museum quality · Ancient yet futuristic · Minimal yet emotionally powerful  

---

### ORIGIN

This is not decoration.  
This is not superstition.  
This is **visual medicine**.

Nine living forms.  
Four layers each.  
One quiet practice.

When a form appears in ordinary life — clock, receipt, door, page —  
the image returns, the feeling returns, the glyph can be traced,  
and the sky-story can be named.

Personal, not prophetic.  
Symbolic, not a false planet catalog.

---

### FOUR LAYERS (every form)

| Layer | Question | Example (form 7) |
|-------|----------|------------------|
| **Feel** | What do I feel? | BALANCE |
| **Form** | How does energy move? | Receive → give → receive |
| **Move** | What is the smallest action? | Trace seven; find the opposite edge |
| **Sky** | Where in the chart? | ♄ Saturn · mapped eight |

Form **9** sky = **Beyond the eight · Universe · the Unknown** (never a planet).

---

### THE NINE PILLARS

| # | Word | Feeling | Geometry | Sky | Kind |
|---|------|---------|----------|-----|------|
| 1 | LOVE | Seed · unconditional presence | Vertical line · initiation | ☀ Sun | Mapped eight |
| 2 | SHARING | Generosity · connection | Curve into ground | ☿ Mercury | Mapped eight |
| 3 | DESIRE | Healthy longing | Open loop | ♀ Venus | Mapped eight |
| 4 | PURPOSE | Path underfoot | Space–time cross | ♂ Mars | Mapped eight |
| 5 | SELF | Growth · not a statue | Angle that curves | 🌍 Earth | Mapped eight |
| 6 | JOY | Gratitude · release grip | Inward spiral | ♃ Jupiter | Mapped eight |
| 7 | BALANCE | Both edges | Receive → give → receive | ♄ Saturn | Mapped eight |
| 8 | HOME | Belonging · guard the loop | Double loop | ♆ Neptune | Mapped eight |
| 9 | THE UNIVERSE | Completion as gift | Within → ground | ✦ Universe · the Unknown | **Beyond the eight** |

Full kinetic text: `system/GEOMETRY_MAP.md`  
Full celestial text: `system/CELESTIAL_MAP.md`

---

### SITE & CELESTIAL LAWS

1. Visible numerals on the public site: **only 1–9**.  
2. No empty-mark (zero) as content. No “top ten” lists.  
3. Forms **1–8** = **mapped eight**.  
4. Form **9** = **beyond the eight** — Universe · the Unknown — **never** called a planet.  
5. Always keep astronomy honesty available (eight official planets; Planet Nine hypothesis ≠ our form nine).  
6. Negative space is sacred. One primary nature metaphor per form.  
7. Sky pill on imagery for visual consistency (main gallery + cards).  
8. Sticky interactive tabs on the main site; clear pill labels (never run-on text).

---

### VISUAL LAWS

1. Negative space is sacred.  
2. One primary metaphor per number.  
3. Texture over ornament.  
4. Light tells the emotion.  
5. Typography whispers.  
6. No faces that demand identity.  
7. No religious symbols as doctrine.  
8. Nature is the teacher.  
9. Timeless over trendy.

---

### COLOR SYSTEM

| Name | Hex | Role |
|------|-----|------|
| Forest Green | `#1F3A2E` | Depth, growth |
| Deep Ocean | `#0E2433` | Mystery, calm |
| Warm Earth | `#5C4033` | Ground, body |
| Ivory | `#F4F0E6` | Breath, paper |
| Stone Grey | `#8A8680` | Soft structure |
| Sunset Gold | `#C4A35A` | Warmth, accent |
| Copper | `#B87333` | Human touch |
| Olive | `#6B6E3F` | Living stillness |
| Moon White | `#F7F7F2` | Soft light |
| Soft Black | `#1A1A18` | Ink, night |

Max 3 colors + ivory/black per composition when possible.

---

### TYPOGRAPHY

- **Word:** Cormorant Garamond / elegant serif  
- **Digit:** Light architectural sans  
- **Sky pill:** Micro uppercase, letterspaced, on dark translucent chip  
- **Tabs:** Pill buttons, readable tracking (avoid ultra-wide tracking that collapses labels)

See also: `system/TYPOGRAPHY_OVERLAYS.md`

---

### PRODUCT SURFACES

Meditation cards · Social carousel · Posters/canvas · Wallpapers · Journals · Apparel · Stickers · Metal/wood · Mugs · Phone cases · Brand campaigns  

All surfaces should be able to express **Feel · Form · Move · Sky** without clutter (one sky accent is enough).

---

### UI CHROME (current)

- Sticky top nav with pill tabs + scroll-spy  
- Gallery: glyph top-right · sky pill bottom-left · kind label under title  
- Detail: sky pill on image · layered copy  
- Products hub: `products/index.html`

---

*Number Medicine · Design Bible · Eight then beyond · Designed to be inherited*
