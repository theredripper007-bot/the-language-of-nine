# THE CELESTIAL MAP
## Sky layer of the Language of Nine

> A **symbolic framework** for reflection and mindfulness.  
> Not a substitute for astronomy.

---

## The simple structure

| Forms | What they are |
|-------|----------------|
| **1 – 8** | The **mapped eight** — Sun, Mercury, Venus, Mars, Earth, Jupiter, Saturn, Neptune |
| **9** | **Beyond the eight** — **the Universe · the Unknown** |

Form nine is **never** called a planet.  
It is what remains when the chart of eight ends: the whole, and the mystery beyond every map.

---

## Astronomy honesty

| Fact | Status |
|------|--------|
| Officially recognized planets in our Solar System | **Eight** (Mercury through Neptune) |
| The Sun | A **star**, not a planet — still the source of the system in our symbolic chart |
| Earth | One of the eight planets — and the ground of human self in our chart |
| Our forms 1–8 | A **symbolic sky chart** (star + planets + home world), not a 1:1 IAU lecture |
| **Form 9** | **Not a planet.** **Universe · the Unknown** — beyond the eight |
| Planet Nine (science) | An **unobserved scientific hypothesis** about a possible distant world. Interesting, separate, and **not** required for form nine |

---

## Three layers of each form

1. **Emotional medicine** — how to feel  
2. **Geometric kinetic map** — how energy moves  
3. **Celestial story** — sky correspondence (1–8) or **beyond** (9)

---

## Correspondences

| Form | Celestial | Kind | Emotion | Geometry (short) |
|------|-----------|------|---------|------------------|
| **1** | ☀ **Sun** | Star · source | LOVE | Vertical line · initiation |
| **2** | ☿ **Mercury** | Planet · messenger | SHARING | Curve into ground |
| **3** | ♀ **Venus** | Planet · attraction | DESIRE | Open loop |
| **4** | ♂ **Mars** | Planet · action | PURPOSE | Space–time cross |
| **5** | 🌍 **Earth** | Planet · human ground | SELF | Angle that curves |
| **6** | ♃ **Jupiter** | Planet · expansion | JOY | Inward spiral · loosen |
| **7** | ♄ **Saturn** | Planet · structure | BALANCE | Receive → give → receive |
| **8** | ♆ **Neptune** | Planet · depth | HOME | Double loop · guard |
| **9** | ✦ **Universe · the Unknown** | **Beyond the eight** | THE UNIVERSE | Within → ground · completion |

### Why eight, then beyond

The official solar system names **eight planets**.  
Our chart uses eight luminous roles (including the Sun as source and Earth as self), then refuses to invent a ninth planet.

**Beyond the eight** is enough:

- **Universe** — the total field that holds every world  
- **the Unknown** — humility before what no instrument has finished  

*(Optional contemplative synonym some practitioners also use: “God” for sacred source — never required, never claimed as a sky object.)*

### Why Neptune for eight

**HOME** is depth, belonging, ocean-soul. Neptune fits that weather.  
Uranus remains an alternate if a future series stresses radical uniqueness.

---

## Optional enrichment

| Form | Element | Tree | Animal | Virtue |
|------|---------|------|--------|--------|
| 1 | Fire | Oak | Eagle | Love as source |
| 2 | Air | Bamboo | Dove | Sharing as message |
| 3 | Water | Cherry | Swan | Desire as beauty |
| 4 | Earth | Pine | Wolf | Purpose as path |
| 5 | Spirit | Banyan | Human | Self as rings |
| 6 | Sky | Cedar | Elephant | Joy as abundance |
| 7 | Stone | Olive | Owl | Balance as wisdom |
| 8 | Ocean | Willow | Whale | Home as depth |
| 9 | Cosmos | World Tree | Phoenix | Universe · Unknown as return |

---

## Practice

When a form appears:

1. **Feel** the medicine word  
2. **Trace** the glyph  
3. **Name** the sky — or, for nine, say: *beyond the eight: the Universe · the Unknown*  
4. Take the **smallest action**

---

## Brand law

- Forms **1–8** = the mapped eight  
- Form **9** = **beyond** · Universe · the Unknown  
- Never call form nine a planet  
- Clarity about astronomy is part of the medicine  

*Number Medicine · Celestial Map · Eight, then beyond*
